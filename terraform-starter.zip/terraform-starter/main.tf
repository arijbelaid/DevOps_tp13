# TP13 partie 3 : ressources à créer dans Floci.

resource "aws_s3_bucket" "uploads" {
  bucket = "tp13-uploads-${var.environment}"
}

# TODO : activer le versioning du bucket (aws_s3_bucket_versioning)
# TODO : bloquer tout accès public (aws_s3_bucket_public_access_block, les 4 options à true)
# TODO : chiffrement côté serveur par défaut (aws_s3_bucket_server_side_encryption_configuration, AES256)

# TODO : file SQS "tp13-contact-${var.environment}" avec une file de lettres mortes (redrive_policy, maxReceiveCount = 3)

# TODO : table DynamoDB "tp13-visits-${var.environment}"
#        billing_mode = "PAY_PER_REQUEST", clé de partition "id" de type "S"

# TODO : secret Secrets Manager "tp13/${var.environment}/api-key" (aws_secretsmanager_secret)
#        sans mettre la valeur dans le code : utilisez une variable sensitive = true
