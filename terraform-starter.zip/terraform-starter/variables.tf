variable "region" {
  description = "Région AWS simulée"
  type        = string
  default     = "us-east-1"
}

variable "floci_endpoint" {
  description = "URL du endpoint Floci"
  type        = string
  default     = "http://localhost:4566"
}

variable "environment" {
  description = "Nom de l'environnement (dev, staging, prod)"
  type        = string
  default     = "dev"

  # TODO (partie 4) : ajouter un bloc validation qui n'accepte que dev, staging ou prod
}
